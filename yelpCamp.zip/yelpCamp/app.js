const express = require('express');
const path = require('path');
const app = express();
const mongoose = require('mongoose');
const Campground = require('./models/campground')
const methodOverride = require('method-override')
const responseTime = require('response-time')

mongoose.connect('mongodb://localhost:27017/yelp-camp',{
	useNewUrlParser:true,
	useCreateIndex:true,
	useUnifiedTopology:true,
	
})

const db = mongoose.connection;
db.on("error", ()=>console.log("erro de conexão"))
db.once("open",()=>{
	console.log("banco conectado")
})

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))

app.use(express.urlencoded({extend:true}))
app.use(methodOverride('_method'))

app.get('/', (req, res)=>{
	res.render('home')
})



app.get('/campgrounds', async (req, res)=>{
	const camp = await Campground.find({});
	res.render('campgrounds/index.ejs', { camp })
})

app.get('/campgrounds/new', async (req, res)=>{
	res.render('campgrounds/new.ejs');
})

app.get('/campgrounds/:id', async (req, res)=>{
	const { id } = req.params;
	const campgroundSelected = await Campground.findById(id);
	res.render('campgrounds/show.ejs', { campgroundSelected });
})

app.get('/campgrounds/:id/edit', async (req, res)=>{
	const { id } = req.params;
	const campgroundSelected = await Campground.findById(id);
	res.render('campgrounds/edit.ejs', { campgroundSelected });
})

app.post('/campgrounds', async(req, res)=>{
	const {title, location} = req.body.campground;
	const newCampground = new Campground({title: title, location:location});
	await newCampground.save();
	res.redirect(`/campgrounds/${newCampground._id}`);
	console.log(newCampground)
})

app.put('/campgrounds/:id', async (req, res)=>{
		const { id } = req.params;
	    const {title, location} = req.body.campground;
        const updated = await Campground.findByIdAndUpdate(id, {title: title, location: location })
		console.log(updated);
	    res.redirect(`/campgrounds/${updated._id}`);
	    console.log(id);
		})
app.delete('/campgrounds/:id', async (req, res)=>{
	    const {id} = req.params;
	    const deletado = await Campground.findByIdAndDelete(id);
	    console.log(id)
	    console.log(deletado)
	    res.redirect('/campgrounds')
})



app.listen(3000, () => console.log("server on at the port 3000"))